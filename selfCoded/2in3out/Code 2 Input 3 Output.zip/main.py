import sys, os
sys.path.append(os.getcwd())
import fixedPattern
import sampleMethod

from mlp import MLP

import torch



if __name__ == '__main__':

    test_sample = list()
    output = list()
    for i in range(11):
        for j in range(11):
            test_sample.append([i/10, j/10])

    Pattern = fixedPattern.Pattern(sampleMethod.classify)

    for elem in test_sample:
        out = Pattern.execute_function(elem)
        output.append(out)

    for i in range(len(test_sample)):
        print("Input {}: Output {}".format(test_sample[i],output[i]))



    # Define the AND function dataset
    inputs = torch.tensor(test_sample, dtype=torch.float32)
    targets = torch.tensor(output, dtype=torch.float32)

    # Instantiate the model, loss function, and optimizer
    model = MLP()

    # Training loop
    epochs = 1000000
    for epoch in range(epochs):
        model.train(inputs, targets)

    #model.plot_progress()

    # Test the trained model
    with torch.no_grad():
        test_inputs = torch.tensor([[0.1, 0.3], [0.1, 1.0], [1, 0.7], [0.7, 1]], dtype=torch.float32)
        predictions = model(test_inputs)
        print("\nTest Predictions:")
        for i in range(len(test_inputs)):
            print(f'Input: {test_inputs[i].tolist()}, Prediction: {torch.round(predictions[i])}')




#%%

#%%
