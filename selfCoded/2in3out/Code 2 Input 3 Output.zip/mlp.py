import torch.nn as nn
import torch.optim as optim
import pandas
from collections import OrderedDict

# Define the MLP model
class MLP(nn.Module):
    def __init__(self):
        super(MLP, self).__init__()


        self.model = nn.Sequential(OrderedDict([
            ('fc1', nn.Linear(2, 3)),
            ('sigmoid1', nn.Sigmoid()),
            ('fc2', nn.Linear(3,3)),
            ('sigmoid2', nn.Sigmoid())])
        )

        self.loss_function = nn.BCELoss()

        self.optimiser = optim.SGD(self.parameters(), lr=0.1)


        self.counter = 0
        self.progress = []

    def forward(self, inputs):
        return self.model(inputs)


    def train(self,inputs, targets):

        outputs = self.forward(inputs)

        loss = self.loss_function(outputs, targets)

        self.counter += 1;
        if (self.counter % 10 == 0):
            self.progress.append(loss.item())
            pass
        if (self.counter % 10000 == 0):
            print("counter = ", self.counter)
            pass

        # zero gradients, perform a backward pass, update weights
        self.optimiser.zero_grad()
        loss.backward()
        self.optimiser.step()

        return self

    def plot_progress(self):
        df = pandas.DataFrame(self.progress, columns=['loss'])
        df.plot(ylim=(0), figsize=(16,8), alpha=0.1, marker='.', grid=True, yticks=(0, 0.25, 0.5, 1.0, 5.0))
        pass